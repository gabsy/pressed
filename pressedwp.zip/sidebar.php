<aside class="sidebar">
		<!-- #search -->
		<div id="search-aside" class="search">
			<form id="searchform" action="<?php echo home_url( '/' ); ?>" method="get">
				<input type="text" id="s" name="s" value="<?php echo "search blog"; ?>" onFocus="this.value=''" />
			</form>
		</div>
		<!-- END #search -->
		<!-- popular posts -->
		<div class="widget" id="popular-posts">
			<h3 class="widget-title">Recommanded articles</h3>
			<ul>
			<?
			query_posts('tag=recommended&showposts=5');
			while ( have_posts() ) : the_post();?>
			  <li><a href="<?php the_permalink()?>">
			    <?php the_title();?>
			   </a></li>
			<?php endwhile;
			wp_reset_query();
			?>
			</ul>
		</div>
		<!-- end popular posts -->
		<!-- Sidebar Widgets Area -->
		<?php dynamic_sidebar( 'sidebar' ); ?>
		<!-- END Sidebar Widgets Area -->
	</aside>